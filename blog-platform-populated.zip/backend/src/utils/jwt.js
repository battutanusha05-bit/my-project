const jwt = require('jsonwebtoken');
const ACCESS_TTL = '15m';
const REFRESH_TTL = '7d';

function signAccess(payload){
  return jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: ACCESS_TTL });
}
function signRefresh(payload){
  return jwt.sign(payload, process.env.JWT_REFRESH_SECRET, { expiresIn: REFRESH_TTL });
}
function verify(token, secret=process.env.JWT_SECRET){
  return jwt.verify(token, secret);
}
module.exports = { signAccess, signRefresh, verify };
