const prisma = require('../db');

async function createPost(req, res) {
  const { title, content, tags = [], excerpt } = req.body;
  if (!title || !content) return res.status(400).json({ error: 'Title & content required' });
  const post = await prisma.post.create({ data: { title, content, tags, excerpt, authorId: req.user.id } });
  res.status(201).json(post);
}

async function listPosts(req, res){
  const page = parseInt(req.query.page || '1');
  const take = 10; const skip = (page - 1) * take;
  const items = await prisma.post.findMany({ skip, take, orderBy: { createdAt: 'desc' } });
  const total = await prisma.post.count();
  res.json({ items, total });
}

async function getPost(req, res){
  const id = parseInt(req.params.id);
  const post = await prisma.post.findUnique({ where: { id } });
  if(!post) return res.status(404).json({ error: 'Not found' });
  res.json(post);
}

module.exports = { createPost, listPosts, getPost };
