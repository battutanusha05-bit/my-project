const express = require('express');
const router = express.Router();
const postsCtrl = require('../controllers/posts');
const auth = require('../middleware/auth');

router.get('/', postsCtrl.listPosts);
router.get('/:id', postsCtrl.getPost);
router.post('/', auth, postsCtrl.createPost);

// AI suggest endpoint using OpenAI
router.post('/:id/suggest', auth, async (req, res) => {
  const { id } = req.params;
  const { OpenAI } = require('openai');
  const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });
  const post = await require('../db').post.findUnique({ where: { id: parseInt(id) } });
  if(!post) return res.status(404).json({ error: 'Not found' });

  const prompt = `Create 3 alternate titles, 5 tags, and a 2-sentence excerpt for the following blog content:\n\nTitle: ${post.title}\nContent: ${post.content}`;
  try {
    const resp = await client.responses.create({ model: 'gpt-4o-mini', input: prompt });
    const text = (resp.output && resp.output[0] && resp.output[0].content) ? JSON.stringify(resp.output) : JSON.stringify(resp);
    res.json({ raw: resp, text });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'AI error', details: err.message });
  }
});

module.exports = router;
