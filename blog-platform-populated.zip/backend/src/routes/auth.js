const express = require('express');
const bcrypt = require('bcrypt');
const router = express.Router();
const prisma = require('../db');
const jwtUtils = require('../utils/jwt');

router.post('/register', async (req, res) => {
  const { email, password, name } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email + password required' });
  const hashed = await bcrypt.hash(password, 10);
  try {
    const user = await prisma.user.create({ data: { email, password: hashed, name } });
    const token = jwtUtils.signAccess({ id: user.id, email: user.email });
    res.json({ user: { id: user.id, email: user.email, name: user.name }, accessToken: token });
  } catch (err) {
    res.status(400).json({ error: 'User exists or invalid data' });
  }
});

router.post('/login', async (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) return res.status(400).json({ error: 'Email + password required' });
  const user = await prisma.user.findUnique({ where: { email } });
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });
  const ok = await bcrypt.compare(password, user.password);
  if (!ok) return res.status(401).json({ error: 'Invalid credentials' });
  const token = jwtUtils.signAccess({ id: user.id, email: user.email });
  res.json({ accessToken: token, user: { id: user.id, email: user.email, name: user.name } });
});

module.exports = router;
