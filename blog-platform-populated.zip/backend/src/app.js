require('dotenv').config();
const express = require('express');
const cors = require('cors');
const path = require('path');
const app = express();

app.use(cors());
app.use(express.json());
app.use('/uploads', express.static(path.join(__dirname, '..', 'uploads')));

app.use('/api/v1/auth', require('./routes/auth'));
app.use('/api/v1/posts', require('./routes/posts'));

app.get('/', (req, res) => res.json({ ok: true }));

module.exports = app;
