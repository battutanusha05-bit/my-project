import React, { useEffect } from 'react'
import { useDispatch, useSelector } from 'react-redux'
import { fetchPosts } from './features/posts/postsSlice'

export default function App(){
  const dispatch = useDispatch();
  const { list, loading } = useSelector(s=>s.posts);

  useEffect(()=>{ dispatch(fetchPosts({ page:1 })) }, [dispatch]);

  return (
    <div style={{ padding: 20 }}>
      <h1>Blog Platform</h1>
      {loading ? <p>Loading...</p> : (
        <div>
          {list.map(p=> (
            <div key={p.id} style={{ border: '1px solid #ddd', padding: 12, marginBottom: 8 }}>
              <h3>{p.title}</h3>
              <p>{p.excerpt || p.content.slice(0, 200)}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  )
}
