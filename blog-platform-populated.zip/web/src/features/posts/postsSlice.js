import { createSlice, createAsyncThunk } from '@reduxjs/toolkit';
import api from '../../utils/api';

export const fetchPosts = createAsyncThunk('posts/fetch', async ({ page = 1, q = '' } = {}) => {
  const res = await api.get(`/posts?page=${page}&search=${encodeURIComponent(q)}`);
  return res.data;
});

const postsSlice = createSlice({
  name: 'posts',
  initialState: { list: [], loading: false, page: 1, total: 0 },
  extraReducers: (builder) => {
    builder.addCase(fetchPosts.pending, (s) => { s.loading = true; })
      .addCase(fetchPosts.fulfilled, (s, action) => {
        s.loading = false;
        s.list = action.payload.items;
        s.total = action.payload.total;
      });
  }
});

export default postsSlice.reducer;
