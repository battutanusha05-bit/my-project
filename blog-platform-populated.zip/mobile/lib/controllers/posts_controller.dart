import 'package:get/get.dart';
import 'package:dio/dio.dart';
import '../models/post.dart';

class PostsController extends GetxController {
  var posts = <Post>[].obs;
  var loading = false.obs;

  Future<void> fetchPosts({int page = 1}) async {
    loading.value = true;
    try {
      final res = await Dio().get('http://10.0.2.2:4000/api/v1/posts?page=$page');
      posts.assignAll((res.data['items'] as List).map((e) => Post.fromJson(e)).toList());
    } catch (e) {
      print('error $e');
    }
    loading.value = false;
  }
}
