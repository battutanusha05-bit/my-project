import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../controllers/posts_controller.dart';

class HomeScreen extends StatelessWidget {
  final ctrl = Get.put(PostsController());
  @override
  Widget build(BuildContext context) {
    ctrl.fetchPosts();
    return Scaffold(
      appBar: AppBar(title: Text('Blog')),
      body: Obx((){
        if(ctrl.loading.value) return Center(child: CircularProgressIndicator());
        return ListView.builder(
          itemCount: ctrl.posts.length,
          itemBuilder: (_, i) {
            final p = ctrl.posts[i];
            return ListTile(title: Text(p.title), subtitle: Text(p.content.substring(0, p.content.length>100?100:p.content.length)));
          }
        );
      }),
    );
  }
}
