# Blog Platform - Full Project

This repository contains a full-stack blog platform starter:
- Backend: Node.js + Express + Prisma + PostgreSQL
- Web: React + Vite + Redux Toolkit
- Mobile: Flutter + GetX

Follow the README and .env.example files in each folder to run locally.
